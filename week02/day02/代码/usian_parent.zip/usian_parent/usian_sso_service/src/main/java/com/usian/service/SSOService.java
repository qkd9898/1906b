package com.usian.service;

import com.usian.pojo.TbUser;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

public interface SSOService {

    boolean checkUserInfo(String checkValue, Integer checkFlag);

    Integer userRegister(TbUser user);

    Map userLogin(String username, String password);

    TbUser getUserByToken(String token);

    Boolean logOut(String token);
}
